#include<stdio.h>
int main(){
	int temp ;
	
	printf("enter a tempreture in celcious:");
	scanf("%d",&temp);
	
	if(temp<0){
		printf("freezing wether");
	}
	else if (temp >=0 && temp <=10){
		printf("very cold wether");
	}
	else if (temp>10 && temp <=20){
		printf("cold wether");
	}
	else if (temp>20 && temp <=30){
		printf("normal temp");
	}
	else if (temp>30 && temp <=40){
		printf("hot tempreture");
	}
	else{
		printf("very hot temoreture");
	}
}