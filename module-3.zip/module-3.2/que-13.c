#include<stdio.h>
int main(){
	int num1,num2,num3;
	
	printf("enter num1 value :");
	scanf("%d",&num1);
	
	printf("enter num2 value :");
	scanf("%d",&num2);
	
	printf("enter num3 value :");
	scanf("%d",&num3);
	
	int min = ((num1<num2) && (num1<num3)) ? num1  : ((num2<num3) ? num2 : num3);
	
	printf("min number is %d",min);
}