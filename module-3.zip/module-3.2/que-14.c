#include<stdio.h>
int main(){
	int num1,num2,num3;
	
	printf("enter 3 value :");
	scanf("%d%d%d",&num1,&num2,&num3);
	
	if(num1>num2 && num1>num3){
		printf("num1 is big number :%d",num1);
	}
	else if (num2>num1 && num2>num3){
		printf("num2 is big number :%d",num2);
	}
	else{
		printf("num3 is big number :%d",num3);
	}
}