#include<stdio.h>
int main(){
    int num1;

    printf("enter value of num1 :");
    scanf("%d",&num1);

    if( num1 < 1){
        printf("your number is nagative");
    }
    else if( num1 == 0){
        printf("your number is zero ");
    }
    else{
        printf("your number is positive");
    }
}