#include<stdio.h>
int main(){
    char alphabet;

   

    printf("enter any one alphbet :");
    scanf(" %c",&alphabet);

    if( alphabet== 'a'||alphabet== 'e'||alphabet== 'i'||alphabet== 'o'||alphabet== 'i'||alphabet== 'A'||alphabet== 'E'||alphabet== 'I'||alphabet== 'O'||alphabet== 'I' ){
        printf("your charecter is vowel :");

    }
    else{
        printf("your cherecter is not vowel");
    }
}