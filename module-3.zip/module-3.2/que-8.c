#include<stdio.h>
int main(){
    int height ;

    printf("enter person hight in cm :");
    scanf("%d",&height);

    if(height > 185){
        printf(" person height is tall person ");
    }
    else if(height > 167 && height < 185){
        printf("person height is avrage ");
    }
    else{
        printf("person hight is short ");
    }
}