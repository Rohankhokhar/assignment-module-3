#include<stdio.h>
int main(){
	int num ;
	
	printf("enter a number :");
	scanf("%d",&num);
	
	(num % 2 == 0) ? printf("your number is even") : printf("your number is odd");
}