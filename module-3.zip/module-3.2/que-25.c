#include<stdio.h>
int main(){
    int moth_number , daysinmonth ;

    printf("enter a month number :");
    scanf("%d",moth_number);

    switch(moth_number){
        case  1:
        daysinmonth =31;
        break;
        case  2:
        daysinmonth =28;
        break;
        case  3:
        daysinmonth =31;
        break;
        case  4:
        daysinmonth =30;
        break;
        case  5:
        daysinmonth =31;
        break;
        case  6:
        daysinmonth =30;
        break;
        case  7:
        daysinmonth =31;
        break;
        case  8:
        daysinmonth =31;
        break;
        case  9:
        daysinmonth =30;
        break;
        case  10:
        daysinmonth =31;
        break;
        case  11:
        daysinmonth =30;
        break;
        case  12:
        daysinmonth =31;
        break;
        default :
         printf("enter valid number ");
    }

    printf("%d month days is %d",moth_number,daysinmonth);
}