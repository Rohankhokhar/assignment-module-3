#include<stdio.h>
int main(){
    float unitconsumed ,totalbill ;

    printf("enter consumede unit value :");
    scanf("%f",&unitconsumed);

    if(unitconsumed<=50){
        totalbill = unitconsumed*0.50;
    }
    else if(unitconsumed >50 && unitconsumed<=150){
        totalbill = 50 * 0.50 + (unitconsumed - 50) * 0.75;
    }
    else if(unitconsumed >150 && unitconsumed<=250){
        totalbill = 50 * 0.50 + 100 * 0.75 + (unitconsumed - 150) * 1.20;
    }
    else{
        totalbill = 50 * 0.50 + 100 * 0.75 + 100 * 1.20 + (unitconsumed - 250) * 1.50;
    }

    totalbill += totalbill*0.20;

    printf("your totall bill is %f",totalbill);


}