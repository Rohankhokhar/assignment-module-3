#include<stdio.h>
int main(){
    int guj ,hindi , english ,computer ,maths;

    printf("enter gujrati subject marks :");
    scanf("%d",&guj);

    printf("enter hindi subject marks :");
    scanf("%d",&hindi);

    printf("enter english subject marks :");
    scanf("%d",&english);

    printf("enter computer subject marks :");
    scanf("%d",&computer);

    printf("enter maths subject marks :");
    scanf("%d",&maths);

    int total = guj + hindi + english + computer + maths ;
    int percentage = total / 5 ;

    if( guj >33 && hindi >33 && english > 33 &&computer >33 && maths >33){
        printf("you are a pass ");
        printf("your total marks is :%d\n",total);
        printf("your percentage is :%d\n",percentage);
    }
    else{
        printf("you are a fail ");
        printf("your total marks is :%d\n",total);
        printf("your percentage is :%d\n",percentage);
    }
}