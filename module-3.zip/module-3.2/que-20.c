#include<stdio.h>
int main(){
    int customerid,unitconsumed;
    char customername[50];
    float totalamount;

    printf("enter customer id :");
    scanf("%d",&customerid);

    printf("enter customer name :");
    scanf(" %s",&customername);

    printf("enter a unitconsumed :");
    scanf("%d",&unitconsumed);

    if(unitconsumed < 350){
        totalamount = unitconsumed * 1.20 ;
    }
    else if(unitconsumed >= 350 && unitconsumed <= 600){
        totalamount = unitconsumed*1.50;
    }
    else if(unitconsumed >600 && unitconsumed <=800){
        totalamount =unitconsumed*1.80;
    }
    else{
        totalamount = unitconsumed*2.00;
    }
    if(totalamount>800){
        totalamount += totalamount * 0.18;
    }

    if(totalamount<256){
        totalamount = 256;
    }
    
    
    printf("customer id :%d",customerid);
    printf("customer name :%s",customername);
    printf("consumedunit :%d",unitconsumed);
    printf("bill total amount :%.2f",totalamount);
}