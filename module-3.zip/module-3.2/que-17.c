#include<stdio.h>
int main(){
	int a1 ,a2 ,a3;
	
	printf("enter triangle angle 1 value :");
	scanf("%d",&a1);
	
	printf("enter triangle angle 2 value :");
	scanf("%d",&a2);
	
	printf("enter triangle angle 3 value :");
	scanf("%d",&a3);
	
	if(a1+a2+a3 == 180 && a1>0 && a2>0 && a3>0){
		printf("triangle is formed");
	}
	else{
		printf("triangle is not formed");
	}
}