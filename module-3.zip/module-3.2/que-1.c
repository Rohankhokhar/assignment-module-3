#include<stdio.h>
int main(){
    int num1,num2;

    printf("enter value of num1:");
    scanf("%d",&num1);

    printf("enter value of num2:");
    scanf("%d",&num2);

    if(num1==num2){
        printf("num1 and num2 is equal");
    }
    else{
        printf("num1 and num2 is not equal");
    }
}