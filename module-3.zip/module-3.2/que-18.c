#include<stdio.h>
int main(){
    int  costprice , sellprice , profitorloss ;

    printf("enter cost price :");
    scanf("%d",&costprice);

    printf("enter sell price :");
    scanf("%d",&sellprice);

    profitorloss = sellprice - costprice ;

    if( profitorloss>0){
        printf("you are in profit");
    }
    else{
        printf("you are in loss");
    }
}