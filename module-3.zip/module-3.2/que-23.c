#include<stdio.h>
int main(){
    int weekn;
    

    printf("enter week mumber :");
    scanf("%d",&weekn);

    switch(weekn){
        case 1:
          printf("monday");
        break;  
        case 2:
          printf("tuesday");
        break;  
        case 3:
          printf("wensaday");
        break;  
        case 4:
          printf("thersday");
        break;  
        case 5:
          printf("friday");
        break;  
        case 6:
          printf("saturday");
        break;  
        case 7:
          printf("sunday");
        break;  
    }
}