#include<stdio.h>
int main(){
    char ch;

    printf("enter a character :");
    scanf("%c",&ch);

    if(isupper(ch)){
        printf("it is uper case character ");
    }
    else if(islower(ch)){
        printf("it is lower case character ");
    }
    else if(isdigit(ch)){
        printf("it is digit");

    }
    else{
        printf("it is special character ");
    }
}