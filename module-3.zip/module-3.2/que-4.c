#include<stdio.h>
int main(){
    int num1,num2,ans;
    char opretor;

    printf("enter your opretor(+,-,*,/,%%):-");
    scanf(" %c",&opretor);

    printf("enter value of num1:");
    scanf("%d",&num1);

    printf("enter value of num2:");
    scanf("%d",&num2);

    if(opretor=='+'){

    ans = num1+num2;
    printf("answer is %d",ans);

    }
    else if(opretor == '-'){

        ans =num1-num2;
        printf("answer is %d",ans);
    }
    else if(opretor == '*'){

        ans = num1*num2;
        printf("answer is %d",ans);
    }
    else if(opretor == '/'){

        ans = num1/num2;
        printf("answer is %d",ans);
    }
    else if(opretor == '%%'){
        ans = num1%num2;
        printf("your ans is %d",ans);
    }
    else{
        printf("enter right opretor:");
    }
}