#include<stdio.h>
int main(){
	int num1,num2,num3;
	
	printf("enter a number 1 value :");
	scanf("%d",&num1);
	
	printf("enter a number 2 value :");
	scanf("%d",&num2);
	
	printf("enter a number 3 value :");
	scanf("%d",&num3);
	
    int big =	(num1 > num2 && num1 > num3) ? num1 : ((num2>num3) ? num2: num3);
    
    printf("the big number is %d",big);
	
}