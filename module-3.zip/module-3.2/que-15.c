#include<stdio.h>
 int main(){
	int math ,phy , chem , total , math_phy_total ;
	
	printf("enter math markes :");
	scanf("%d",&math);
	
	printf("enter phy markes :");
	scanf("%d",&phy);
	
	printf("enter chem markes :");
	scanf("%d",&chem);
	
	printf("enter total markes :");
	scanf("%d",&total);
	
	printf("enter math and physics total markes :");
	scanf("%d",&math_phy_total);
	
	if(math>=65 && phy>=55 && chem>=50 &&total>=190){
		printf("candidate is aligable");
	}
	else if(math_phy_total>=140){
		printf("candidate is aligable");
	}
	else{
		printf("candidate is not aligable");
	}
}
