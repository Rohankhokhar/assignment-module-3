#include <stdio.h>

int main() {
    int number, first_digit, last_digit, sum;
    int abs_number

    printf("enter a number: ");
    scanf("%d", &number);

    abs_number = number < 0 ? -number : number;

    last_digit = abs_number % 10;

    while (abs_number >= 10) {
        abs_number /= 10;
    }
    first_digit = abs_number;

    sum = first_digit + last_digit;

    if (number < 0) {
        sum = -sum;
    }


    printf("sum of first and last number : %d\n", sum);

    

}
