#include<stdio.h>

int main() {
    int number, remainder, reversed = 0;

   
    printf("enter number: ");
    scanf("%d", &number);

    while (number!=0){
        remainder = number % 10;
        reversed = reversed * 10 + remainder;
        number = number / 10;
    }
    printf("reversed number: %d\n", reversed);

    
    
    }
