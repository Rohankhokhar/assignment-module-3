#include <stdio.h>

long long factorial(int num) {
    long long fact = 1;
    for (int i = 1; i <= num; ++i) {
        fact *= i;
    }
    return fact;
}

int main() {
    int numbers[5];
    
    printf("enter 5 number:\n");
    for (int i = 0; i < 5; ++i) {
        printf("number %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }

    for (int i = 0; i < 5; ++i) {
        printf("The factorial of %d is %lld\n", numbers[i], factorial(numbers[i]));
    }

    return 0;
}
