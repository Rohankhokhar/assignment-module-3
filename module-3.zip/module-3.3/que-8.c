#include <stdio.h>

int main() {
    int number, max_digit = -1;

    printf("enter number: ");
    scanf("%d", &number);

  
    number = number < 0 ? -number : number;

    while (number > 0) {
        int digit = number % 10; 
        if (digit > max_digit) {
            max_digit = digit; 
        }
        number /= 10; 
    }

   
    printf("maximum digit is: %d\n", max_digit);

    


    
}
