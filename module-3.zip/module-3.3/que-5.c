#include<stdio.h>
int main(){
    int n ,i;
    int fact =1;

    printf("enter factorial number ");
    scanf("%d",&n);

    for(i=1;i<=n;i++){
    fact = fact * i ;
    
    

    }
  printf("factoril number is %d",fact);
    
}