#include<stdio.h>
int main(){
    int i , n ;
    n = 897 ;

    for(i=972;i>=n;i--){
        printf("%d\n",i);
    }
}