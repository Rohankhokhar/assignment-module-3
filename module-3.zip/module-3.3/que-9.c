#include <stdio.h>

int main() {
    int number, abc_number , digit ,sum = 0;

    printf("enter number: ");
    scanf("%d", &number);

    abs_number = number < 0 ? -number : number;

    while (abs_number > 0) {
        digit = abs_number % 10; 
        sum += digit; 
        abs_number /= 10; 
    }

    if (number < 0) {
        sum = -sum;
    }

    printf("sum of num: %d\n", sum);

    

}
