#include <stdio.h>

int main() {
    int i = 0;
    
    while (i < 3) {
        int num, originalnum, reversednum = 0, remainder;
        
        printf("enter number %d: ",i + 1);
        scanf("%d", &num);

        originalnum = num;

        while (num != 0) {
            remainder = num % 10;
            reversednum = reversednum * 10 + remainder;
            num /= 10;
        }

        if (originalnum == reversednum) {
            printf("%d is a palindrome.\n", originalnum);
        } 
        else {
            printf("%d is not a palindrome.\n", originalNum);
        }

        i++;
    }

}
