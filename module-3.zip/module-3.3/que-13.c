#include<stdio.h>
int main(){
    int num , fact = 1;
    int i = 1;

    printf("enter number :");
    scanf("%d",&num);

    while(i <= num){
    
    fact = fact * i ;

    i++;
   
    }
     printf("factorial number is %d",fact);


}